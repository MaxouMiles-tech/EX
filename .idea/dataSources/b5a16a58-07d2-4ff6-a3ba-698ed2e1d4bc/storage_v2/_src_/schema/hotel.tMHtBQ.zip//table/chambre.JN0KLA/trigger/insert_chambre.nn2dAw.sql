create definer = root@localhost trigger insert_chambre
    before insert
    on chambre
    for each row
BEGIN
    	DECLARE capacite INT;
    	DECLARE id_hotel INT;
    	SET id_hotel = NEW.cha_hot_id;
    	SET capacite  =  (SELECT sum(cha_capacite) 
								FROM chambre 
								WHERE cha_hot_id = id_hotel
								GROUP BY cha_hot_id);
    	if capacite > 50
		then   	
        SIGNAL SQLSTATE '40000' SET MESSAGE_TEXT = "il n'est  !";
	END if ;
END;

