create definer = root@localhost trigger insert_reservation
    before insert
    on reservation
    for each row
BEGIN
    	DECLARE resa INT;
    	SET resa  =  (SELECT COUNT(res_id) AS countId 
						FROM reservation 
						JOIN chambre ON chambre.cha_id = reservation.res_cha_id
						JOIN hotel ON hotel.hot_id = chambre.cha_hot_id
						GROUP BY hot_id);
    	if resa > 10
		then   	
        SIGNAL SQLSTATE '40000' SET MESSAGE_TEXT = "il n'est  !";
	END if ;
END;

