create
    definer = root@localhost procedure listeClient()
BEGIN
    SELECT cli_id, cli_nom, cli_prenom, cli_ville FROM client;
END;

