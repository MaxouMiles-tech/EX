create definer = root@localhost trigger insert_reservation2
    before insert
    on reservation
    for each row
BEGIN
    	DECLARE resa_client INT;
    	SET resa_client  =  (SELECT COUNT(res_id) AS countId 
						FROM reservation 
						JOIN client ON client.cli_id = reservation.res_cli_id
						GROUP BY cli_id
						);
    	if resa_client > 3
		then   	
        SIGNAL SQLSTATE '40000' SET MESSAGE_TEXT = "il n'est  !";
	END if ;
END;

