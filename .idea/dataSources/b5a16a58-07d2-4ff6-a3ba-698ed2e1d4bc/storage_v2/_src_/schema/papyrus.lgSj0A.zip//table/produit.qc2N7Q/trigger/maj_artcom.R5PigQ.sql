create definer = root@localhost trigger maj_artcom
    after update
    on produit
    for each row
BEGIN
          DECLARE id_a CHAR(4);
          DECLARE stkdiff int;
          DECLARE stkcom INT;
          DECLARE qtetot INT;
          DECLARE countrow INT;

          SET stkdiff = (NEW.stkale - NEW.stkphy);
          SET id_a = NEW.codart;
          SET stkcom = (SELECT SUM(qte) FROM articleacommander where codart = id_a);
          SET countrow = (SELECT COUNT(qte) FROM articleacommander where codart = id_a);

         IF NEW.stkphy < NEW.stkale THEN
               IF countrow < 1 THEN
                INSERT INTO articleacommander (codart, dated, qte) VALUES (id_a, NOW(), stkdiff);
             ELSE
                 SET qtetot = (stkdiff - stkcom);
                 INSERT INTO articleacommander (codart, datedujour, qte) VALUES (id_a, NOW(), qtetot);
            END IF;
          END IF;
END;

