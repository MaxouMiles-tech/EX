create
    definer = root@localhost procedure derniereDateCommande(IN client varchar(40))
BEGIN
    SELECT Max(OrderDate) AS 'Date de dernière commande'
    FROM Customers
    JOIN Orders ON customers.CustomerID = orders.CustomerID
    JOIN `order details` ON orders.OrderID = `order details`.OrderID
    WHERE CompanyName = "Du monde entier";
END;

