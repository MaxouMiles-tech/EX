create
    definer = root@localhost procedure delaiLivraison()
BEGIN
    SELECT round(AVG(DATEDIFF(ShippedDate, OrderDate)))  AS 'Délai moyen de livraison en jours'
    FROM Orders;
END;

